<?php 

require 'views/checkout.view.php';
?>