<?php
    require 'views/createCourse.view.php';
?>