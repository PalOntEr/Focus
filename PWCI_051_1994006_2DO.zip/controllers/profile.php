<?php 

require 'views/profile.view.php';

?>