<?php 

require 'views/kardex.view.php';
?>