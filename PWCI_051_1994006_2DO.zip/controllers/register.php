<?php 

require 'views/register.view.php';
?>