<?php

    require 'views/home.view.php';

?>