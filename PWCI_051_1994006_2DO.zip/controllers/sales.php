<?php 

require 'views/sales.view.php';
?>