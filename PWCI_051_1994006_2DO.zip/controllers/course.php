<?php

    require 'views/course.view.php';

?>