<?php

    require 'views/chats.view.php';

?>