<?php

    require 'views/advSearch.php';

?>