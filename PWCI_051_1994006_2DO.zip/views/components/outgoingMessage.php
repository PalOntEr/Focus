<div class="flex flex-col items-end">
    <div class="bg-secondary text-color rounded-md px-3 py-1 mb-px inline-block justify-self-end w-1/3">
        Fine, and you?
    </div>
    <div class="mb-2">
        <p class="text-sm text-color">8:30pm</p>
    </div>
</div>