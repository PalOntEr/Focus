<div class="flex flex-col w-1/3">
    <div class="bg-secondary text-color rounded-md px-3 py-1 mb-px">
        Hello, how are you?
    </div>
    <div class="flex justify-between mr-2">
        <p class="text-sm text-color">8:30pm</p>
        <p class="text-sm text-color">Seen</p>
    </div>
</div>