<div class="flex flex-col justify-center w-full sm:w-auto items-center p-2 h-full bg-primary rounded-2xl">
    <div class="justify-center w-2/3 items-center mb-4 bg-color rounded-2xl  h-full bg-primary">
        <img class="w-auto h-auto rounded-2xl" src="https://static.wikia.nocookie.net/ultra-custom-night/images/f/f6/Purple_Freddy.png" alt="Course">
    </div>
    <div class="w-full text-comp-2 font-semibold">
        PHP Course
    </div>
    <div class="flex justify-between w-full font-semibold">
        <div class="text-secondary">Instructor</div>
        <div class="text-secondary">4.3/5⭐</div>
    </div>
</div>