<div class="flex items-center space-x-2 w-full">
    <img class="h-10 w-10 rounded-full" src="https://www.iconpacks.net/icons/2/free-user-icon-3296-thumb.png" alt="">
    <div class="w-full">
        <h2 class="text-lg text-color font-bold">Dobeto</h2>
        <div class="flex justify-between w-full">
            <p class="text-sm hidden text-color md:block">Hello, how are you?</p>
            <p class="text-sm text-color">8:30pm</p>
        </div>
    </div>
</div>