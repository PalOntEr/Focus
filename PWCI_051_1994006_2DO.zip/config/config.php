
<?php

return [
    "database" => [
        "host" => "localhost",
        "user" => "root",
        "password" => "1234",
        "dbname" => "db_pcwi",
        "port" => "3306",
    ],
];
